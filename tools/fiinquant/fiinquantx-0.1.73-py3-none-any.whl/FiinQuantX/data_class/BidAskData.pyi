import pandas as pd

class BidAskData:
    """BidAskData is a class that represents bid-ask data of a stock. This class is 
    a structure that contains all the information of a stock at a specific time. You can use 
    the to_dict () method to convert this class to a dictionary(recommended) or to_dataFrame() method to convert this class to a pandas DataFrame."""
    
    ComGroupCode: str
    StockType: str
    Ticker: str
    TradingDate: str
    Timestamp: str
    Spread: float
    SpreadDelta: float
    DepthImbalance: float

    TotalBuyTradeVolume: int
    TotalSellTradeVolume: int
    TotalBidVolume: int
    TotalAskVolume: int

    Best1Bid: float
    Best2Bid: float
    Best3Bid: float
    Best4Bid: float
    Best5Bid: float
    Best6Bid: float
    Best7Bid: float
    Best8Bid: float
    Best9Bid: float
    Best10Bid: float

    Best1Ask: float
    Best2Ask: float
    Best3Ask: float
    Best4Ask: float
    Best5Ask: float
    Best6Ask: float
    Best7Ask: float
    Best8Ask: float
    Best9Ask: float
    Best10Ask: float

    Best1BidVolume: int
    Best2BidVolume: int
    Best3BidVolume: int
    Best4BidVolume: int
    Best5BidVolume: int
    Best6BidVolume: int
    Best7BidVolume: int
    Best8BidVolume: int
    Best9BidVolume: int
    Best10BidVolume: int

    Best1AskVolume: int
    Best2AskVolume: int
    Best3AskVolume: int
    Best4AskVolume: int
    Best5AskVolume: int
    Best6AskVolume: int
    Best7AskVolume: int
    Best8AskVolume: int
    Best9AskVolume: int
    Best10AskVolume: int

    BidPriceDelta1: float
    BidPriceDelta2: float
    BidPriceDelta3: float
    BidPriceDelta4: float
    BidPriceDelta5: float
    BidPriceDelta6: float
    BidPriceDelta7: float
    BidPriceDelta8: float
    BidPriceDelta9: float
    BidPriceDelta10: float

    AskPriceDelta1: float
    AskPriceDelta2: float
    AskPriceDelta3: float
    AskPriceDelta4: float
    AskPriceDelta5: float
    AskPriceDelta6: float
    AskPriceDelta7: float
    AskPriceDelta8: float
    AskPriceDelta9: float
    AskPriceDelta10: float

    BidVolumeDelta1: int
    BidVolumeDelta2: int
    BidVolumeDelta3: int
    BidVolumeDelta4: int
    BidVolumeDelta5: int
    BidVolumeDelta6: int
    BidVolumeDelta7: int
    BidVolumeDelta8: int
    BidVolumeDelta9: int
    BidVolumeDelta10: int

    AskVolumeDelta1: int
    AskVolumeDelta2: int
    AskVolumeDelta3: int
    AskVolumeDelta4: int
    AskVolumeDelta5: int
    AskVolumeDelta6: int
    AskVolumeDelta7: int
    AskVolumeDelta8: int
    AskVolumeDelta9: int
    AskVolumeDelta10: int

    VWAPBid: float
    VWAPAsk: float
    VWAPBidSpread: float
    VWAPAskSpread: float
    VWAPBidAskSpread: float
    OrderFlowImbalance: float


    def to_dict(self) -> dict:
        """Return dictionary representation of the dataclass (recommended use)."""
        ...

    
    def to_dataFrame(self) -> pd.DataFrame:
        """Return dataframe representation of the dataclass (slower than to_dict method)."""
        ...