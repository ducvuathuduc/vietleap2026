import pandas as pd
from typing import Literal, Union
from datetime import datetime
class PriceStatistics(object):
    def __init__(self) -> None:...

    def get_overview(
        self,
        tickers: Union[list, str],
        time_filter: Literal["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"],
        from_date: str ,
        to_date: str = datetime.now().strftime("%Y-%m-%d")
    ) -> pd.DataFrame: ...
    
    def get_foreign(
        self,
        tickers: Union[list, str],
        time_filter: Literal["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"],
        from_date: str,
        to_date: str = datetime.now().strftime("%Y-%m-%d")
    ) -> pd.DataFrame:...

    def get_ceilingfloor(
        self, 
        tickers:Union[list,str], 
        from_date: str, 
        to_date: str = datetime.now().strftime("%Y-%m-%d")
    ) ->pd.DataFrame:...

    def get_value_by_investor(
        self, 
        tickers:Union[list,str], 
        from_date: str,
        to_date: str = datetime.now().strftime("%Y-%m-%d")
    ) -> pd.DataFrame: ...

    def get_freefloat(
        self, 
        tickers: Union[list, str], 
        from_date: str, 
        to_date = datetime.now().strftime("%Y-%m-%d")
    ) -> pd.DataFrame: ...