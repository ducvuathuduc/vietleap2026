import pandas as pd
from typing import Union, List, Optional, Tuple

class RRG:
    def __init__(
        self,
        tickers: Union[str, List[str]],
        benchmark: str,
        by: str = '1d',
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        period: Optional[int] = None,
    ) -> None: ...
    
    def get(self) -> pd.DataFrame: ...
    
    def filter(
        self,
        tickers: Optional[Union[str, List[str]]] = None,
        date: Optional[str] = None,
        phase: Optional[str] = None,
        rs_min: Optional[float] = None,
        rs_max: Optional[float] = None,
        rm_min: Optional[float] = None,
        rm_max: Optional[float] = None,
        changed_only: bool = False,
    ) -> pd.DataFrame: ...
    
    def plot(
        self,
        tickers: Optional[Union[str, List[str]]] = None,
        latest_only: bool = False,
        figsize: Tuple[int, int] = (12, 8),
        trail_length: int = 100,
    ) -> None: ...
