import pandas as pd
from typing import Literal

BASE_URL = "https://apigw.fiingroup.vn/FTMA/MoneyFlow/GetContribution"

class MoneyFlow:
    def __init__(self) ->None: ...

    def get_contribution(
        self,
        ticker: str,
        contribution_day: Literal["1Day", "5Day", "10Day", "20Day"],
        type: Literal["topGainers", "topLosers"],
        top: int = 15
    ) -> pd.DataFrame:...
