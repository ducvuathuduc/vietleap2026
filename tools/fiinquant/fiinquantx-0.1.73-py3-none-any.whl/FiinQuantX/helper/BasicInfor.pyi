import pandas as pd
from typing import Union


class BasicInfor(pd.DataFrame):
    def __init__(self, tickers: Union[str, list]) -> None :
        ...
    def get() -> pd.DataFrame: ...



