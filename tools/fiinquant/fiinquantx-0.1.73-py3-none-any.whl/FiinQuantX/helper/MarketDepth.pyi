import pandas as pd
from typing import Union
from datetime import datetime

class MarketDepth(object):
    def __init__(self, access_token: callable) -> None: ...
    def get_stock_valuation(self, tickers: Union[list, str],
                           from_date: str, to_date: str = datetime.now().strftime("%Y-%m-%d")) -> pd.DataFrame: 
        ...

    def get_sector_valuation(self, tickers: Union[list, str], level: int,
                            from_date: str, to_date: str = datetime.now().strftime("%Y-%m-%d")) -> pd.DataFrame:
        ...
            
    def get_index_valuation(self, tickers: Union[list, str], 
                           from_date: str, to_date: str = datetime.now().strftime("%Y-%m-%d")) -> pd.DataFrame:
        ...
