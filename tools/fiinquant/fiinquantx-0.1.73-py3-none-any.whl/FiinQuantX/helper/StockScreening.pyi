import pandas as pd
from datetime import datetime

class StockScreening(object):
    def __init__(self) -> None: ...

    def get(self,
            filter: list[dict],
            exchanges: list = [],
            screenerDate: str = datetime.now().strftime("%Y-%m-%d"),
            sectors: list = []
    ) -> dict: ...

    def get_indicator_configs(self, indicator_names: str | list) -> list[dict]: ...
