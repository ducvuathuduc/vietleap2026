# This code is encrypted and does not contain viruses or Trojans.
import warnings
from typing import Union, List
warnings.filterwarnings("ignore")
      
class TickerList:
    def __init__(self, access_token: callable, 
                 ticker: Union[str, List[str]] = None,
                 tickers: Union[List[str], str, None] = None) -> None:...

