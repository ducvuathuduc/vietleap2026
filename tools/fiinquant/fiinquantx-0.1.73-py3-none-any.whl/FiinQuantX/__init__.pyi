
# This code is encrypted and does not contain viruses or Trojans.
from datetime import datetime
from typing import Union, Any, Literal
import pandas as pd

from .core.Aggregates import BarDataUpdate
from .FiinQuant import FiinSession
from .ta.FiinIndicator import _FiinIndicator
from .core.Fetch_Trading_Data import Fetch_Trading_Data
from .core.Trading_Data_Stream import Trading_Data_Stream
# from .helper.DateCorr import FindDateCorrelation
from .helper.Rebalance import Rebalance
# from .helper.SimilarChart import SimilarChart
from .helper.GetDataPoint import GetDataPoint
from .core.BidAsk import BidAsk
from .helper.TickerList import TickerList
from .core.TrackingOrderBook import OrderBook
from .core.FundamentalAnalysis import FundamentalAnalysis
from .helper.PriceStatistics import PriceStatistics
from .helper.BasicInfor import BasicInfor
from .helper.MarketBreadth import MarketBreadth
from .helper.MarketDepth import MarketDepth
from .helper.MoneyFlow import MoneyFlow
from .helper.StockScreening import StockScreening
from .ta.Pattern import Pattern
from .helper.RRG import RRG
from .data_class import RealTimeData, BidAskData
from typing import Union, List, Optional
from .FiinQuantConnector import FiinQuantConnector

class FiinSession:
    """
    This class is used to create a session to access FiinQuant.
    """
    def __init__(self, username: str, password: str):...

    def login(self) -> FiinSession: ...
        
    def FiinIndicator(self) -> _FiinIndicator: 
        """
        FiinIndicator class is used to calculate technical indicators for stock market data.
        """
    def Trading_Data_Stream(self, tickers: list, callback: callable) -> Trading_Data_Stream: 
        """
        Using this class to stream real-time stock market matching data. Using start() to start streaming and stop() to stop streaming.
        The variable _stop is used to check if the streaming is stopped or not."""
    def Fetch_Trading_Data(self, realtime: bool, tickers: list, fields: list, adjusted: bool, 
                           period: Union[int, None] = None, by: str='1m',
                           from_date: Union[str, datetime, None] = None,
                           to_date: Union[str, datetime, None] = None,
                           callback: callable = None,
                           wait_for_full_timeFrame: bool = False,
                           lasted: Union[bool, None] = None) -> Fetch_Trading_Data: 

        """summary:
        
        This function is used to fetch trading data from the server. The data can be fetched in real-time or historical data.
        lasted only required when realtime = False. When lasted=True, the last candle is an unfinished candle. When lasted=False, the last candle is a completed historical candle.
        callback and wait_for_full_timeFrame only required when realtime = True. Method stop() is used to stop receiving data (only needed when realtime = True).
        
        Args:
            realtime (bool): Real-time data or not.
            tickers (list): List of tickers.
            fields (list): List of fields. Including: 'open', 'high', 'low', 'close', 'volume', 'bu', 'sd', 'fb', 'fs', 'fn'. Can use 'full' for get all fields.
            adjusted (bool, optional): Adjusted price or unadjusted price. Default to True (Adjusted).
            period (Union[int, None], optional): Number of most recent candles. Default to None.
            by (str, optional): Unit of time: '1m', '5m', '15m', '30m', '1h', '2h', '4h', '1d'. Default to '1m'.
            from_date (Union[str, datetime, None], optional): The furthest time of data. Default to None.
            to_date (Union[str, datetime, None], optional): Latest time of data. Default to None.
            callback (callable, optional): User-defined callback function for manipulating data. Default to None.
            wait_for_full_timeFrame (bool, optional): Wait until the candle is over to get data or not. Default to False.
            lasted (Union[bool, None], optional): Last candle is unfinished or not. Default to None.
        Methods:
            get_data(): Get data from the server.
            stop(): Stop receiving data (only need when realtime = True).
        """
    def FindDateCorrelation(self) -> FindDateCorrelation: 
        """
        Using this class to find the correlation between today data and the past data.
        """
    def Rebalance(self) -> Rebalance: 
        """Use this class for Rebalance."""
    def SimilarChart(self) -> SimilarChart: 
        """Use this class for Find Similar Pattern."""

    def GetDataPoint(self, ticker: str, field: str, by: str, candle_index: int, adjusted: Union[bool,None] = True) -> GetDataPoint: 
        """
        This class is used to get one point data of a stock.  
        """
    def BidAsk(self, tickers: Union[list[str], str], callback: callable) -> BidAsk: 
        """
        Using this class to stream real-time stock market bid-ask data. Using start() to start streaming and stop() to stop streaming.
        The variable _stop is used to check if the streaming is stopped or not.
        """
    def TickerList(self, ticker: Union[str, List[str]] = None, tickers: Union[List[str], str, None] = None) -> TickerList: 
        """
        Using this class to get the list of tickers in the market.
        """

    def FundamentalAnalysis(self) -> FundamentalAnalysis:
        """
        Using this class to get fundamental analysis data of a stock.
        """
    def OrderBook(self) -> OrderBook:
        """
        Using this class to track order book changes.
        """
    def PriceStatistics(self) -> PriceStatistics:
        """
        Using this class to get PriceStatistics.
        """
    def BasicInfor(self, tickers) -> BasicInfor:
        """
        Using this class to get BasicInfor of Ticker.
        """
    def MarketBreadth(self) ->MarketBreadth:
        """
        Using this class to get MarketBreadth.
        """
        
    def MarketDepth(self) ->MarketDepth:
        """
        Using this class to get MarketDepth.
        """
        
    def MoneyFlow(self) ->MoneyFlow:
        """
        Using this class to get MoneyFlow of Index.
        """

    def Pattern(self) -> Pattern:
        """
        Using this class to Recognize Pattern.
        """

    def RRG(self,tickers: Union[str, List[str]],
        benchmark: str,
        by: str = '1d',
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        period: Optional[int] = None,) -> RRG:
        """
        Using this class to compute RRG phases for one or multiple tickers relative to a benchmark.
        """
    def StockScreening(self) -> StockScreening:
        """
        Using this class to screening.
        """
    def FiinQuantConnector(self,
        broker: str,
        username: str, 
        password: str,
        smart_otp: bool = False) -> FiinQuantConnector: ...
    """
        Use this class to connect to securities companies.
    """

        
# class FindDateCorrelation(object):
#     """
#     Using this class to find the correlation between today data and the past data.
#     """
#     def __init__(self) -> None: ...
    
#     def intraday_Correlation(self, Ticker: Union[str, list[str]], Timeframe: str, 
#                             t1: str = None, t2: str = None, method: str = "pearson correlation",
#                             year: int = 1) -> None:
#         """
#         Plot the normalized price of a stock over time, comparing the current day to the past days.
#         method (str, optional): Distance measurement. Default to "pearson correlation".
#         For simple, use '1' for euclidean distance, '2' for dynamic time warping, 
#         '3' for pearson correlation, '4' for cosine similarity.
#         """


class Rebalance(object):
    """Use this class for Rebalance."""
    def __init__(self) -> None:...
    def get(self, Budget: int, Ticker: str) -> pd.DataFrame:...
    
# class SimilarChart(object):
#     """Use this class for find Similar Pattern."""
#     def __init__(self)->None:...
#     def plot(self, Ticker: Union[str, list[str]], t1:Union[str,None] = None, t2:Union[str,None] = None)->None:
#         """Plot the similar chart of a Ticker."""

    
class RealTimeData:

    """RealTimeData is a class that represents a real-time data of a stock. This class is 
    a structure that contains all the information of a stock at a specific time. You can use to_dict() method
    to convert this class to a dictionary (recommend) or to_dataFrame() method to converta pandas DataFrame."""

    def __init__(self, data: pd.DataFrame) -> None:
        self.__private_attribute = data
        self.Ticker: str
        self.TotalMatchVolume: int
        self.MarketStatus: str
        self.TradingDate: str
        self.Timestamp: str
        self.ComGroupCode: str
        self.ReferencePrice: float
        self.Open: float
        self.Close: float
        self.High: float
        self.Low: float
        self.Change: float
        self.ChangePercent: float
        self.MatchVolume: int
        self.MatchValue: float
        self.TotalMatchValue: float
        self.TotalBuyTradeVolume: int
        self.TotalSellTradeVolume: int
        self.TotalDealVolume: int
        self.TotalDealValue: float
        self.ForeignBuyVolumeTotal: int
        self.ForeignBuyValueTotal: float
        self.ForeignSellVolumeTotal: int
        self.ForeignSellValueTotal: float
        self.Bu: int
        self.Sd: int
        self.TotalStockUpPrice: int
        self.TotalStockDownPrice: int
        self.TotalStockNoChangePrice: int
        self.TotalStockOverCeiling: int
        self.TotalStockUnderFloor: int
    def to_dataFrame(self) -> pd.DataFrame: ...
    def to_dict(self) -> dict: ...

class BarDataUpdate:
    """
    This class is used to store both the real-time data and the historical data of a stock.
    You can use to_dataFrame() method to convert this data to a pandas.
    
    """
    def __init__(self, data) -> None:
        self.__private_attribute: pd.DataFrame
        self.timestamp: Union[str, datetime]
        self.open: float
        self.high: float
        self.low: float
        self.close: float
        self.volume: int
        self.ticker: str
        self.bu: int
        self.sd: int
        self.fb: float
        self.fs: float
        self.fn: float

    def to_dataFrame(self) -> pd.DataFrame: ...

class BidAskData:
    """BidAskData is a class that represents bid-ask data of a stock. This class is 
    a structure that contains all the information of a stock at a specific time. You can use 
    the to_dict () method to convert this class to a dictionary(recommended) or to_dataFrame() method to convert this class to a pandas DataFrame."""

    ComGroupCode: str
    StockType: str
    Ticker: str
    TradingDate: str
    Timestamp: str
    Spread: float
    SpreadDelta: float
    DepthImbalance: float

    TotalBuyTradeVolume: int
    TotalSellTradeVolume: int
    TotalBidVolume: int
    TotalAskVolume: int

    Best1Bid: float
    Best2Bid: float
    Best3Bid: float
    Best4Bid: float
    Best5Bid: float
    Best6Bid: float
    Best7Bid: float
    Best8Bid: float
    Best9Bid: float
    Best10Bid: float

    Best1Ask: float
    Best2Ask: float
    Best3Ask: float
    Best4Ask: float
    Best5Ask: float
    Best6Ask: float
    Best7Ask: float
    Best8Ask: float
    Best9Ask: float
    Best10Ask: float

    Best1BidVolume: int
    Best2BidVolume: int
    Best3BidVolume: int
    Best4BidVolume: int
    Best5BidVolume: int
    Best6BidVolume: int
    Best7BidVolume: int
    Best8BidVolume: int
    Best9BidVolume: int
    Best10BidVolume: int

    Best1AskVolume: int
    Best2AskVolume: int
    Best3AskVolume: int
    Best4AskVolume: int
    Best5AskVolume: int
    Best6AskVolume: int
    Best7AskVolume: int
    Best8AskVolume: int
    Best9AskVolume: int
    Best10AskVolume: int

    BidPriceDelta1: float
    BidPriceDelta2: float
    BidPriceDelta3: float
    BidPriceDelta4: float
    BidPriceDelta5: float
    BidPriceDelta6: float
    BidPriceDelta7: float
    BidPriceDelta8: float
    BidPriceDelta9: float
    BidPriceDelta10: float

    AskPriceDelta1: float
    AskPriceDelta2: float
    AskPriceDelta3: float
    AskPriceDelta4: float
    AskPriceDelta5: float
    AskPriceDelta6: float
    AskPriceDelta7: float
    AskPriceDelta8: float
    AskPriceDelta9: float
    AskPriceDelta10: float

    BidVolumeDelta1: int
    BidVolumeDelta2: int
    BidVolumeDelta3: int
    BidVolumeDelta4: int
    BidVolumeDelta5: int
    BidVolumeDelta6: int
    BidVolumeDelta7: int
    BidVolumeDelta8: int
    BidVolumeDelta9: int
    BidVolumeDelta10: int

    AskVolumeDelta1: int
    AskVolumeDelta2: int
    AskVolumeDelta3: int
    AskVolumeDelta4: int
    AskVolumeDelta5: int
    AskVolumeDelta6: int
    AskVolumeDelta7: int
    AskVolumeDelta8: int
    AskVolumeDelta9: int
    AskVolumeDelta10: int

    VWAPBid: float
    VWAPAsk: float
    VWAPBidSpread: float
    VWAPAskSpread: float
    VWAPBidAskSpread: float
    OrderFlowImbalance: float
    
    def to_dict(self) -> dict:
        """Return dictionary representation of the dataclass (recommended use)."""
        ...

    
    def to_dataFrame(self) -> pd.DataFrame:
        """Return dataframe representation of the dataclass (slower than to_dict method)."""
        ...
# Connectors
from .connector.base.base_data import *
from .connector.dnse import *
from .connector.order_book import OrderBook, DerivativeOrderBook

# Connector entry

class FiinQuantConnector:
    username: str
    password: str
    smart_otp: Optional[bool]
    broker: str
    client: Optional[Any]
    accounts: Optional[Any]
    sub_accounts: Optional[Any]

    def __init__(
        self,
        broker: str,
        username: str,
        password: str,
        smart_otp: Optional[bool] = None
    ) -> None: ...
    def login(self) -> "FiinQuantConnector": ...
    def get_orderbook(self, account_id: str, loan_id: Optional[str] = None) -> OrderBook: ...
    def get_derivative_orderbook(
        self,
        account_id: str,
        loan_id: Optional[str] = None,
        take_profit_rate: float = 0.0,
        stop_loss_rate: float = 0.0,
        take_profit_delta_price: float = 0.0,
        stop_loss_delta_price: float = 0.0
    ) -> DerivativeOrderBook: ...
    def get_loan_packages(self, account_id: str) -> List[BaseLoanPackage]: ...
    def get_derivative_loan_packages(self, account_id: str) -> List[BaseDerivativeLoanPackage]: ...
    def get_account_info(self) -> BaseAccountInfo: ...
    def get_sub_accounts(self) -> BaseSubAccountInfo: ...
    def get_balance(self, account_id: str) -> BaseAccountBalance: ...

__all__ = [
    "FiinQuantConnector",
    "FiinSession",
    # "FindDateCorrelation",
    "Rebalance",
    # "SimilarChart",
    "RealTimeData",
    "BarDataUpdate",
    "BidAskData"
]

