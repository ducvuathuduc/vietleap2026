from typing import Union
from datetime import datetime 
from .ta.FiinIndicator import _FiinIndicator
from .core.Fetch_Trading_Data import Fetch_Trading_Data
from .core.Trading_Data_Stream import Trading_Data_Stream
# from .helper.DateCorr import FindDateCorrelation
from .helper.Rebalance import Rebalance
# from .helper.SimilarChart import SimilarChart
from .helper.GetDataPoint import GetDataPoint
from .core.BidAsk import BidAsk
from .helper.TickerList import TickerList
from .core.TrackingOrderBook import OrderBook
from .core.FundamentalAnalysis import FundamentalAnalysis
from .helper.PriceStatistics import PriceStatistics
from .helper.BasicInfor import BasicInfor
from .helper.MarketBreadth import MarketBreadth
from .helper.MarketDepth import MarketDepth
from .helper.MoneyFlow import MoneyFlow
from .ta.Pattern import Pattern
from .helper.RRG import RRG
from .helper.StockScreening import StockScreening
from .FiinQuantConnector import FiinQuantConnector
from typing import Union, List, Optional

class FiinSession:
    def __init__(self, username: str, password: str):...

    def login(self) -> FiinSession: ...
   
    def FiinIndicator(self) -> _FiinIndicator: ...
    
    def Trading_Data_Stream(self, tickers: Union[list[str], str], callback: callable) -> Trading_Data_Stream: ...
    
    def Fetch_Trading_Data(self, 
                           realtime: bool,
                           tickers: Union[list[str], str],
                           fields:list, 
                           adjusted: Union[bool,None] = True, 
                           period:Union[int, None] = None, 
                           by: str = '1m',
                           from_date: Union[str, datetime, None] = None,
                           to_date: Union[str, datetime, None] = None,
                           callback: callable = None,
                           wait_for_full_timeFrame: bool = False,
                           lasted: Union[bool,None] = None) -> Fetch_Trading_Data: ...

    # def FindDateCorrelation (self) -> FindDateCorrelation: ...

    def Rebalance(self) -> Rebalance: ...

    # def SimilarChart(self) -> SimilarChart: ...
    
    def GetDataPoint(self, ticker: str, field: str, by: str, candle_index: int, adjusted: Union[bool,None]) -> GetDataPoint: ...

    def BidAsk(self, tickers: Union[list[str], str], callback: callable) -> BidAsk: ...

    def TickerList(self, ticker: Union[list[str], str] = None, tickers: Union[list[str], str] = None)-> TickerList:...

    def OrderBook(self) -> OrderBook:...

    def FundamentalAnalysis(self) -> FundamentalAnalysis: ...
    
    def PriceStatistics(self) -> PriceStatistics:...
    
    def BasicInfor(self, tickers) -> BasicInfor:...
    
    def MarketBreadth(self) -> MarketBreadth:...
    
    def MarketDepth(self) -> MarketDepth:...
    
    def MoneyFlow(self) -> MoneyFlow:...

    def Pattern(self) -> Pattern:...

    def RRG(self, tickers: Union[str, List[str]],
        benchmark: str,
        by: str = '1d',
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        period: Optional[int] = None) -> RRG:...
    
    def StockScreening(self) -> StockScreening:...
    
    def FiinQuantConnector(self, broker: str, username: str, password: str, smart_otp: bool = False) -> FiinQuantConnector: ...