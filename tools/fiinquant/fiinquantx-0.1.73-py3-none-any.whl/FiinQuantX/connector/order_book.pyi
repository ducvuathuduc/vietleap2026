from typing import Optional, Literal, Union, List, Any
from .dnse.dnse import DNSE  #
from .base.base_data import *

BaseClient = Union[DNSE, Any]  

class OrderBook:
    client: BaseClient
    account_id: str
    loan_id: Optional[str]

    def __init__(self, client: BaseClient, account_id: str, loan_id: Optional[str] = None) -> None: ...
    
    def get_balance(self) -> BaseAccountBalance: ...  
    
    def place_order(
        self,
        ticker: str,
        side: Literal["buy", "sell"],
        quantity: int,
        order_type: Literal["LO", "MP", "MTL", "ATO", "ATC", "MOK", "MAK", "PLO"],
        price: Optional[float] = None
    ) -> BaseOrderResult: ...  
    
    def cancel_order(self, order_id: str) -> BaseOrderResult: ... 
    
    def modify_order(
        self,
        order_id: str,
        new_price: Optional[float] = None,
        new_quantity: Optional[int] = None
    ) -> BaseOrderResult: ...  
    
    def get_order_detail(self, order_id: str) -> BaseOrderResult: ...
    
    def get_list_orders(self, from_date: str | None = None, to_date: str | None = None, ticker: str | None = None, status: str | None = None)-> List[BaseOrderResult]: ...  #
    
    def get_positions(self, ticker: Optional[str] = None, status: Optional[str] = None, side: Optional[str] = None) -> List[BaseDealResult]: ... 

    def get_trading_power(self, ticker: str, price: float) -> BaseTradeCapacity: ...  

class DerivativeOrderBook:
    client: BaseClient
    account_id: str
    loan_id: Optional[str]

    def __init__(self, client: BaseClient, account_id: str, loan_id: Optional[str] = None) -> None: ...
    
    def get_balance(self) -> BaseAccountBalance: ... 
    def place_order(
        self,
        ticker: str,
        side: Literal["buy", "sell"],
        quantity: int,
        order_type: Literal["LO", "MTL", "ATO", "ATC", "MOK", "MAK"],
        price: Optional[float] = None,
        take_profit_rate: float = 0.0,
        stop_loss_rate: float = 0.0,
        take_profit_delta_price: float = 0.0,
        stop_loss_delta_price: float = 0.0,
        take_profit_order_delta_price: float = 0.0,
        stop_loss_order_delta_price: float = 0.0
    ) -> BaseOrderResult: ...  
    
    def cancel_order(self, order_id: str) -> BaseOrderResult: ...
    
    def modify_order(
        self,
        order_id: str,
        new_price: Optional[float] = None,
        new_quantity: Optional[int] = None
    ) -> BaseOrderResult: ...
    
    def get_list_orders(self, from_date: str | None = None, to_date: str | None = None, ticker: str | None = None, status: str | None = None)-> List[BaseOrderResult]: ...  #
    
    def get_order_detail(self, order_id: str) -> BaseOrderResult: ...
    
    def get_positions(self, ticker: Optional[str] = None, status: Optional[str] = None, side: Optional[str] = None) -> List[BaseDealResult]: ...
    
    def get_trading_power(self, ticker: str, price: float) -> BaseTradeCapacity: ... 

    def set_derivative_tp_sl_strategy(
        self,
        *,
        take_profit_rate: float = 0.0,
        stop_loss_rate: float = 0.0,
        take_profit_delta_price: float = 0.0,
        stop_loss_delta_price: float = 0.0,
    ) -> DerivativeOrderBook:...
    
    # def set_risk_for_deal(
    #     self,
    #     deal_id: str,
    #     take_profit_enabled: bool = False,
    #     stop_loss_enabled: bool = False,
    #     take_profit_strategy: Literal['PNL_RATE', 'DELTA_PRICE'] = 'PNL_RATE',
    #     stop_loss_strategy: Literal['PNL_RATE', 'DELTA_PRICE'] = 'PNL_RATE',
    #     take_profit_order_type: Literal['FASTEST', 'DELTA_PRICE'] = 'FASTEST',
    #     stop_loss_order_type: Literal['FASTEST', 'DELTA_PRICE'] = 'FASTEST',
    #     take_profit_rate: float = 0.0,
    #     stop_loss_rate: float = 0.0,
    #     take_profit_delta_price: float = 0.0,
    #     stop_loss_delta_price: float = 0.0,
    #     take_profit_order_delta_price: float = 0.0,
    #     stop_loss_order_delta_price: float = 0.0
    # ) -> Any: ... 
    
    # def derivative_risk_account(
    #     self,
    #     account_id: str,
    #     take_profit_enabled: bool,
    #     stop_loss_enabled: bool,
    #     take_profit_strategy: Literal['PNL_RATE', 'DELTA_PRICE'],
    #     stop_loss_strategy: Literal['PNL_RATE', 'DELTA_PRICE'],
    #     take_profit_rate: float,
    #     stop_loss_rate: float,
    #     take_profit_delta_price: float,
    #     stop_loss_delta_price: float
    # ) -> Any: ...
    
    def close_deal(self, deal_id: str) -> BaseCloseDeal: ... 