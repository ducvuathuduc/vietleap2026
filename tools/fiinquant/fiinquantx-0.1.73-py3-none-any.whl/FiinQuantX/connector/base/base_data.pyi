from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional, Dict, Any, Union, Literal

from ..dnse.data_order import DNSESubAccountInfo, DNSEAccountInfo, DNSEDerivativeLoanPackage  # type: ignore

def _parse_side(side: str) -> str: ...


class BaseAccountInfo(ABC):
    id: Optional[str]
    investor_id: Optional[str]
    name: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseAccountInfo': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseSubAccount(ABC):
    id: Optional[str]
    custody_code: Optional[str]
    investor_id: Optional[str]
    derivative_account: bool
    derivative_status: Optional[str]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BaseSubAccount': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseSubAccountInfo(ABC):
    default: BaseSubAccount
    accounts: Optional[List[BaseSubAccount]]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BaseSubAccountInfo': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseAccountBalance(ABC):
    investor_id: Optional[str]
    account_id: Optional[str]
    custody_code: Optional[str]
    available_cash: float
    stock_value: float
    withdrawable_cash: float
    net_asset_value: float
    margin_debt: float
    margin_rate: float
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseAccountBalance': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseLoanPackage(ABC):
    id: Optional[str]
    type: Optional[str]
    initial_rate: float
    maintenance_rate: float
    interest_rate: float
    preferential_interest_rate: float
    allow_extend: bool
    allow_early_payment: bool
    buy_fee: float
    sell_fee: float
    tickers: Optional[List[str]]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseLoanPackage': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseTradeCapacity(ABC):
    investor_id: Optional[str]
    account_id: Optional[str]
    custody_code: Optional[str]
    available_power: float
    buying_power: float
    selling_power: float
    max_buy_quantity: int
    max_sell_quantity: int
    price: float
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseTradeCapacity': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseDerivativeLoanPackage(ABC):
    id: Optional[str]
    initial_rate: float
    maintenance_rate: float
    liquid_rate: float
    trading_fee: float
    trading_fee_daily_close: float
    ticker_types: Optional[List[str]]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseDerivativeLoanPackage': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseOrderResult(ABC):
    id: Optional[str]
    ticker: Optional[str]
    side: str
    order_type: Optional[str]
    price: float
    quantity: int
    filled: int
    avg_price: float
    modified: Optional[str]
    created: Optional[str]
    status: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseOrderResult': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseDealResult(ABC):
    id: Optional[str]
    ticker: Optional[str]
    account_no: Optional[str]
    side: str
    status: Optional[str]
    quantity: int
    cost_price: float
    market_price: float
    accumulate_quantity: float
    break_even_price: float
    realized_profit: float
    unrealized_profit: float
    created_date: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseDealResult': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseCloseDeal(ABC):
    id: Optional[str]
    ticker: Optional[str]
    side: str
    price: float
    quantity: int
    fill_quantity: int
    average_price: float
    loan_package_id: Optional[str]
    initial_rate: float
    created_date: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseCloseDeal': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseAutoTradeConfigAccount(ABC):
    account_no: Optional[str]
    status: str
    auto_handle_warning: bool
    stop_loss_strategy: Optional[Union[Literal['PNL_RATE', 'DELTA_PRICE'], str]]
    take_profit_strategy: Optional[Union[Literal['PNL_RATE', 'DELTA_PRICE'], str]]
    stop_loss_order_type: Optional[str]
    take_profit_order_type: Optional[str]
    stop_loss_enabled: bool
    take_profit_enabled: bool
    stop_loss_rate: float
    take_profit_rate: float
    stop_loss_delta_price: float
    take_profit_delta_price: float
    stop_loss_order_delta_price: float
    take_profit_order_delta_price: float
    created_date: Optional[str]
    modified_date: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseAutoTradeConfigAccount': ...
    def summary(self) -> Dict[str, Any]: ...


@dataclass
class BaseAutoTradeDealConfig(ABC):
    id: Optional[str]
    deal_id: Optional[str]
    account_no: Optional[str]
    status: str
    auto_handle_warning: bool
    stop_loss_strategy: Optional[Union[Literal['PNL_RATE', 'DELTA_PRICE'], str]]
    take_profit_strategy: Optional[Union[Literal['PNL_RATE', 'DELTA_PRICE'], str]]
    stop_loss_order_type: Optional[str]
    take_profit_order_type: Optional[str]
    stop_loss_enabled: bool
    take_profit_enabled: bool
    stop_loss_rate: float
    take_profit_rate: float
    stop_loss_price: float
    take_profit_price: float
    stop_loss_delta_price: float
    take_profit_delta_price: float
    stop_loss_order_delta_price: float
    take_profit_order_delta_price: float
    stop_loss_amount: float
    take_profit_amount: float
    created_date: Optional[str]
    modified_date: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any], error: Optional[str] = None) -> 'BaseAutoTradeDealConfig': ...
    def summary(self) -> Dict[str, Any]: ...

__all__ = [
    "BaseAccountInfo",
    "BaseSubAccount",
    "BaseSubAccountInfo",
    "BaseAccountBalance",
    "BaseLoanPackage",
    "BaseDerivativeLoanPackage",
    "BaseOrderResult",
    "BaseDealResult",
    "BaseCloseDeal",
    "BaseAutoTradeConfigAccount",
    "BaseAutoTradeDealConfig",
    "BaseTradeCapacity"
]
