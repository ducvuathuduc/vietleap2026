# dnse.pyi
from typing import Optional, Literal, Union, List

from .data_order import (
    DNSEAccountInfo,
    DNSESubAccountInfo,
    DNSEAccountBalance,
    DNSELoanPackage,
    DNSEDerivativeLoanPackage,
    DNSETradeCapacity,
    DNSEOrderResult,
    DNSEDealResult,
    DNSEAutoTradeDealConfig,
    DNSEAutoTradeConfigAccount,
    DNSECloseDeal
)

class DNSE:
    def __init__(self, username: str, password: str) -> None: ...
    
    # Token management
    def get_token(self) -> None: ...
    def _is_valid_token(self) -> None: ...
    def _is_valid_trading_token(self, token: str, exp: int) -> None: ...
    def _decode_jwt(self) -> dict: ...
    def _create_new_token(self) -> None: ...
    def get_trading_token(self, smart_otp: bool = True) -> None: ...
    def _create_new_trading_token(self) -> None: ...
    def _get_smart_otp(self) -> None: ...
    def _get_email_otp(self) -> None: ...

    # Account
    def account(self) -> DNSEAccountInfo: ...
    def sub_accounts(self) -> DNSESubAccountInfo: ...
    def account_balance(self, user_id: str) -> DNSEAccountBalance: ...
    def loan_packages(self, user_id: str) -> List[DNSELoanPackage]: ...
    def trading_power(self, user_id: str, loan_id: str, symbol: str, price: float) -> DNSETradeCapacity: ...

    # Base Order
    def place_order(
        self,
        user_id: str,
        loan_id: str,
        symbol: str,
        side: Literal['buy','sell'],
        order_type: Literal["LO", "MP", "MTL", "ATO", "ATC", "MOK", "MAK", "PLO"],
        quantity: int,
        price: Optional[float] = None
    ) -> DNSEOrderResult: ...

    def order_list(
        self,
        user_id: str,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        symbol: Optional[str] = None,
        status: Optional[str] = None
    ) -> List[DNSEOrderResult]: ...

    def order_detail(self, user_id: str, order_id: str) -> DNSEOrderResult: ...
    def cancel_order(self, user_id: str, order_id: str) -> DNSEOrderResult: ...
    def modify_order(self, user_id: str, order_id: str, price: float, quantity: int) -> DNSEOrderResult: ...
    def deals_list(self, user_id: str) -> List[DNSEDealResult]: ...

    # Derivative
    def derivative_loan_packages(self, user_id: str) -> List[DNSEDerivativeLoanPackage]: ...
    def derivative_trading_power(self, user_id: str, loan_id: str, symbol: str, price: float) -> DNSETradeCapacity: ...
    def place_derivative_order(
        self,
        user_id: str,
        loan_id: str,
        symbol: str,
        side: str,
        order_type: Literal["LO", "MTL", "ATO", "ATC", "MOK", "MAK"],
        quantity: int,
        price: Optional[float] = None
    ) -> DNSEOrderResult: ...

    def derivative_order_list(
        self,
        user_id: str,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        symbol: Optional[str] = None,
        status: Optional[str] = None
    ) -> List[DNSEOrderResult]: ...

    def derivative_order_detail(self, user_id: str, order_id: str) -> DNSEOrderResult: ...
    def cancel_derivative_order(self, user_id: str, order_id: str) -> DNSEOrderResult: ...
    def modify_derivative_order(self, user_id: str, order_id: str, price: float, quantity: int) -> DNSEOrderResult: ...
    def derivative_deals_list(self, user_id: str) -> List[DNSEDealResult]: ...

    # Auto-trade / Risk
    def derivative_risk_deal(
        self,
        deal_id: str,
        take_profit_enabled: bool,
        stop_loss_enabled: bool,
        take_profit_strategy: Literal['PNL_RATE','DELTA_PRICE'],
        stop_loss_strategy: Literal['PNL_RATE','DELTA_PRICE'],
        take_profit_order_type: Literal['FASTEST','DELTA_PRICE'],
        stop_loss_order_type: Literal['FASTEST','DELTA_PRICE'],
        take_profit_rate: float,
        stop_loss_rate: float,
        take_profit_delta_price: float,
        stop_loss_delta_price: float,
        take_profit_order_delta_price: float,
        stop_loss_order_delta_price: float
    ) -> DNSEAutoTradeDealConfig: ...

    def derivative_risk_account(
        self,
        user_id: str,
        take_profit_enabled: bool,
        stop_loss_enabled: bool,
        take_profit_strategy: Literal['PNL_RATE','DELTA_PRICE'],
        stop_loss_strategy: Literal['PNL_RATE','DELTA_PRICE'],
        take_profit_rate: float,
        stop_loss_rate: float,
        take_profit_delta_price: float,
        stop_loss_delta_price: float
    ) -> DNSEAutoTradeConfigAccount: ...

    # Close deal
    def close_deal(self, deal_id: str) -> DNSECloseDeal: ...

    # Positions
    def get_positions(
        self,
        user_id: str,
        symbol: Optional[str] = None,
        status: Optional[str] = None,
        side: Optional[str] = None,
        is_derivative: bool = False
    ) -> List[Union[DNSEDealResult, DNSEOrderResult]]: ...
