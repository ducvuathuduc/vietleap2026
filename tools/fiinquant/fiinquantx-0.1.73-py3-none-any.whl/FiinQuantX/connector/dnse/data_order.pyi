# dnse_data.pyi

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, List
from ..base.base_data import (
    BaseAccountInfo, BaseSubAccount, BaseSubAccountInfo, BaseAccountBalance,
    BaseLoanPackage, BaseTradeCapacity, BaseDerivativeLoanPackage,
    BaseOrderResult, BaseDealResult, BaseCloseDeal,
    BaseAutoTradeConfigAccount, BaseAutoTradeDealConfig
)


def _parse_datetime(s: str) -> Optional[datetime]: ...


class DNSEAccountInfo(BaseAccountInfo):
    id: Optional[str]
    investor_id: Optional[str]
    name: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSEAccountInfo": ...


@dataclass
class DNSESubAccount(BaseSubAccount):
    id: Optional[str]
    custody_code: Optional[str]
    investor_id: Optional[str]
    derivative_account: bool
    derivative_status: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> "DNSESubAccount": ...


@dataclass
class DNSESubAccountInfo(BaseSubAccountInfo):
    default: DNSESubAccount
    accounts: List[DNSESubAccount]

    @classmethod
    def from_dict(cls, data: dict, status_code: Optional[int] = None) -> "DNSESubAccountInfo": ...


class DNSEAccountBalance(BaseAccountBalance):
    investor_id: Optional[str]
    account_id: Optional[str]
    custody_code: Optional[str]
    available_cash: float
    stock_value: float
    withdrawable_cash: float
    net_asset_value: float
    margin_debt: float
    margin_rate: float
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSEAccountBalance": ...


class DNSELoanPackage(BaseLoanPackage):
    id: Optional[str]
    type: Optional[str]
    initial_rate: float
    maintenance_rate: float
    interest_rate: float
    preferential_interest_rate: float
    allow_extend: bool
    allow_early_payment: bool
    buy_fee: float
    sell_fee: float
    tickers: List[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSELoanPackage": ...


class DNSETradeCapacity(BaseTradeCapacity):
    investor_id: Optional[str]
    account_id: Optional[str]
    custody_code: Optional[str]
    available_power: float
    buying_power: float
    selling_power: float
    max_buy_quantity: float
    max_sell_quantity: float
    price: float
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSETradeCapacity": ...


class DNSEDerivativeLoanPackage(BaseDerivativeLoanPackage):
    id: Optional[str]
    initial_rate: float
    maintenance_rate: float
    liquid_rate: float
    trading_fee: float
    trading_fee_daily_close: float
    ticker_types: List[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSEDerivativeLoanPackage": ...


class DNSEOrderResult(BaseOrderResult):
    id: Optional[str]
    ticker: Optional[str]
    side: Optional[str]
    order_type: Optional[str]
    price: float
    quantity: int
    filled: int
    avg_price: float
    status: Optional[str]
    created: Optional[str]
    modified: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSEOrderResult": ...


class DNSEDealResult(BaseDealResult):
    id: Optional[str]
    ticker: Optional[str]
    account_no: Optional[str]
    side: Optional[str]
    status: Optional[str]
    quantity: float
    cost_price: float
    market_price: float
    break_even_price: float
    realized_profit: float
    unrealized_profit: float
    created_date: Optional[str]
    accumulate_quantity: float
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSEDealResult": ...


class DNSECloseDeal(BaseCloseDeal):
    id: Optional[str]
    ticker: Optional[str]
    side: Optional[str]
    price: float
    quantity: int
    fill_quantity: int
    average_price: float
    loan_package_id: Optional[str]
    initial_rate: float
    created_date: Optional[str]
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSECloseDeal": ...


class DNSEAutoTradeConfigAccount(BaseAutoTradeConfigAccount):
    account_no: Optional[str]
    status: str
    auto_handle_warning: bool
    stop_loss_strategy: Optional[str]
    take_profit_strategy: Optional[str]
    stop_loss_order_type: Optional[str]
    take_profit_order_type: Optional[str]
    stop_loss_enabled: bool
    take_profit_enabled: bool
    stop_loss_rate: float
    take_profit_rate: float
    stop_loss_delta_price: float
    take_profit_delta_price: float
    stop_loss_order_delta_price: float
    take_profit_order_delta_price: float
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSEAutoTradeConfigAccount": ...


class DNSEAutoTradeDealConfig(BaseAutoTradeDealConfig):
    id: Optional[str]
    deal_id: Optional[str]
    account_no: Optional[str]
    status: str
    auto_handle_warning: bool
    stop_loss_strategy: Optional[str]
    take_profit_strategy: Optional[str]
    stop_loss_order_type: Optional[str]
    take_profit_order_type: Optional[str]
    stop_loss_enabled: bool
    take_profit_enabled: bool
    stop_loss_rate: float
    take_profit_rate: float
    stop_loss_price: float
    take_profit_price: float
    stop_loss_delta_price: float
    take_profit_delta_price: float
    stop_loss_order_delta_price: float
    take_profit_order_delta_price: float
    stop_loss_amount: float
    take_profit_amount: float
    error: Optional[str]
    status_code: Optional[int]

    @classmethod
    def from_dict(cls, data: dict, error: Optional[str] = None, status_code: Optional[int] = None) -> "DNSEAutoTradeDealConfig": ...
