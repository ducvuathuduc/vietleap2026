# This code is encrypted and does not contain viruses or Trojans.
from typing import Union, List, Optional, Literal
import warnings
warnings.filterwarnings("ignore")

class FundamentalAnalysis:
    def __init__(self) -> None:...

    def get_financial_statement(self, tickers: Union[str, list],
        statement: Literal['balancesheet', 'incomestatement', 'cashflow', 'full'],
        years: Union[List[int], int],
        type: Literal['consolidated', 'separate'],
        audited: Union[bool,None] = None,
        quarters: Union[List[int], int, None] = None,
        fields: Union[str, list, None] = None) -> None: ...

    def get_ratios(self, tickers: Union[list[str], str], years: list,
        quarters: Optional[list] = None,
        type: Literal['consolidated', 'separate'] = "consolidated",
        fields: Optional[list] = None ) -> None:...