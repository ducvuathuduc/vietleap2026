import pandas as pd
import time
from typing import Literal, Callable


class OrderBook(object):
    def __init__(self):
        ...
    def track_order_book_changes(self, ticker_config: dict, callback: Callable[[pd.DataFrame], None], side: str = "all",
                                action: Literal["add", "cancel"] = "cancel", accumulate_window: int = 5) -> None:...
