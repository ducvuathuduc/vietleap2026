from typing import Union
class BidAsk:
    """Using this class to get BidAsk data. """
    def __init__(self, tickers: Union[list[str],str], callback: callable) -> None:
        self.tickers: Union[list[str],str]
        self._stop: bool
        
    def start(self) -> None: ...
        
    def stop(self) -> None: ...

