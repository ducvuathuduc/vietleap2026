import pandas as pd
from typing import Union
from datetime import datetime

class BarData:
    def __init__(self, data) -> None:
        self.__private_attribute: pd.DataFrame = data
        self.timestamp: Union[str, datetime]
        self.open: float
        self.high: float
        self.low: float
        self.close: float
        self.volume: int
        self.ticker: str
        self.bu: int
        self.sd: int
        self.fb: float
        self.fs: float
        self.fn: float
        
    def to_dataFrame(self) -> pd.DataFrame: ...

class BarDataUpdate:
    def __init__(self, data) -> None:
        self.__private_attribute: pd.DataFrame
        self.timestamp: Union[str, datetime]
        self.open: float
        self.high: float
        self.low: float
        self.close: float
        self.volume: int
        self.ticker: str
        self.bu: int
        self.sd: int
        self.fb: float
        self.fs: float
        self.fn: float
        
    def to_dataFrame(self) -> pd.DataFrame: ...

class GetBarData:
    def __init__(self, 
                 tickers: Union[str, list],
                 by: str, 
                 from_date: Union[str, datetime, None], 
                 to_date: Union[str, datetime, None],
                 adjusted: bool, 
                 fields: list, 
                 period: int) -> None: ...
    
    def get(self) -> BarData: ...

