from typing import Optional, Any, List

from .connector.base.base_data import *

from .connector.dnse.data_order import *
from .connector.order_book import OrderBook, DerivativeOrderBook


class FiinQuantConnector:
    username: str
    password: str
    smart_otp: Optional[bool]
    broker: str  # 'dnse', 'ssi', etc.
    client: Optional[Any]
    accounts: Optional[Any]
    sub_accounts: Optional[Any]

    def __init__(
        self,
        broker: str,
        username: str,
        password: str,
        smart_otp: Optional[bool] = None
    ) -> None: ...
    
    def login(self) -> "FiinQuantConnector": ...
    
    # ====================== ORDERBOOK ======================
    def get_orderbook(self, account_id: str, loan_id: Optional[str] = None) -> OrderBook: ...  # Implement per broker
    def get_derivative_orderbook(
        self,
        account_id: str,
        loan_id: Optional[str] = None,
        take_profit_rate: float = 0.0,
        stop_loss_rate: float = 0.0,
        take_profit_delta_price: float = 0.0,
        stop_loss_delta_price: float = 0.0
    ) -> DerivativeOrderBook: ... 

    def get_loan_packages(self, account_id: str) -> List[BaseLoanPackage]: ...
    def get_derivative_loan_packages(self, account_id: str) -> List[BaseDerivativeLoanPackage]: ...
    
    # ====================== UTILITIES ======================
    def get_account_info(self) -> BaseAccountInfo: ...  # Or Union[DNSEAccountInfo, SSIAccountInfo, ...]
    def get_sub_accounts(self) -> BaseSubAccountInfo: ...
    def get_balance(self, account_id: str) -> BaseAccountBalance: ...
